let fname=document.getElementById("fname");
let lname=document.getElementById("lname");
let email=document.getElementById("email");
let mobno=document.getElementById("mobno");
let pwd=document.getElementById("pwd");
let pwd1=document.getElementById("pwd1");

function validate()

{
    if (fname.value==""){
        alert("First name cannot be emptied");
        return false;
    }
    if (lname.value==""){
        alert("Last name cannot be emptied");
        return false;
    }
    else if (email.value==""){
        alert("email cannot be blank");
        return false;
    }
   else if (mob.value==""){
        alert("Mobile number cannot be blank");
        return false;
    }
    else if(mob.value.length<10){
        alert("Please fill mobile number with 10 digits");
        return false;
    }
    else if (pwd.value==""){
        alert("Mobile number cannot be blank");
        return false;
    }
    else if (pwd.value.length<=5){
        alert("password is too short");
        pwd.style.border="2px solid red";
        return false;
    }
    else if (pwd1.value==""){
        alert("Mobile number cannot be blank");
        return false;
    }
    else if (pwd1.value.length<=5){
        alert("password is too short");
        pwd1.style.border="2px solid red";
        return false;
    }
    else{
        return true;
    }

}